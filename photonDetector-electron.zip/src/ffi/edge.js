// var edge = require('electron-edge-js')
// var helloWorld = edge.func(`
//     async (input) => {
//         return ".NET Welcomes " + input.ToString();
//     }
// `)
// const hello = edge.func({
//   assemblyFile: path.join(__static, 'ClassLibrary1.dll'),
//   typeName: 'ClassLibrary1.Class1',
//   methodName: 'hello'
// })

// helloWorld('JavaScript', function (error, result) {
//   if (error) throw error
//   console.log(result)
//   // debugger
// })
// hello(123, (e, r) => {
//   console.log(e, r)
// })
