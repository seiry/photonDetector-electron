/* eslint-disable no-unused-vars */
'use strict'
import { app, BrowserWindow, dialog, ipcMain, Menu } from 'electron'

// import myTest from '../ffi/test'
// import { dllPath } from '../ffi/utils'
// import { myUser32, showText } from '../ffi/user32.js'

// import myTest from '../ffi/test'

/**
 * Set `__static` path to static files in production
 * https://simulatedgreg.gitbooks.io/electron-vue/content/en/using-static-assets.html
 */

let mainWindow
const winURL =
  process.env.NODE_ENV === 'development'
    ? `http://localhost:9080`
    : `file://${__dirname}/index.html`

function createWindow() {
  /**
   * Initial window options
   */
  mainWindow = new BrowserWindow({
    height: 563,
    useContentSize: true,
    width: 1000,
  })

  Menu.setApplicationMenu(null)

  mainWindow.loadURL(winURL)
  mainWindow.openDevTools() // devtools for build
  // const t = myTest()
  // dialog.showMessageBox({
  //   message : `${t.add(1,2)}`,
  //   buttons: []
  // })

  mainWindow.on('closed', () => {
    mainWindow = null
  })
}

app.on('ready', createWindow)

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit()
  }
})

app.on('activate', () => {
  if (mainWindow === null) {
    createWindow()
  }
})

/**
 * Auto Updater
 *
 * Uncomment the following code below and install `electron-updater` to
 * support auto updating. Code Signing with a valid certificate is required.
 * https://simulatedgreg.gitbooks.io/electron-vue/content/en/using-electron-builder.html#auto-updating
 */

/*
import { autoUpdater } from 'electron-updater'

autoUpdater.on('update-downloaded', () => {
  autoUpdater.quitAndInstall()
})

app.on('ready', () => {
  if (process.env.NODE_ENV === 'production') autoUpdater.checkForUpdates()
})
 */
