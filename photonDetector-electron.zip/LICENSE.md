﻿[jszip] <https://github.com/Stuk/jszip/blob/master/LICENSE.markdown>
